package ex4;

public class MyLife {
	public MyLife() {
		System.out.println("MyLife constructor");
	}
	
	public void janam() {
		System.out.println("MyLife After birth");
	}
	
	public void maran() {
		System.out.println("MyLife Before death");
	}
}
