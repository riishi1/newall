package ax2;

public interface MessageService {
	void send(String to, String msg);
}
